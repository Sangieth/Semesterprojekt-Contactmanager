Gruppe
Sangieth Teamleiter
Adnan
Jovan

Funktioniert
Datenerfassung
Löschen
Bearbeiten
Speichern von Mitarbeiterdaten


Wichtig zuerst neu klicken und Formular ausfüllen.